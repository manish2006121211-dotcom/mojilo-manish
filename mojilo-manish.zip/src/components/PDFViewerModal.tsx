import React, { useState } from 'react';
import { 
  X, 
  ExternalLink, 
  Download, 
  FileText, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  Share2,
  Calendar,
  Layers,
  FolderOpen
} from 'lucide-react';
import { PDFItem } from '../types';

interface PDFViewerModalProps {
  pdf: PDFItem | null;
  onClose: () => void;
}

export const PDFViewerModal: React.FC<PDFViewerModalProps> = ({ pdf, onClose }) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [useGoogleViewer, setUseGoogleViewer] = useState<boolean>(true);

  if (!pdf) return null;

  // Format file size
  const formatSize = (bytes: number) => {
    if (!bytes) return 'N/A';
    const mb = bytes / (1024 * 1024);
    if (mb >= 1) return `${mb.toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(0)} KB`;
  };

  const encodedPdfUrl = encodeURIComponent(pdf.storageUrl);
  const googleViewerUrl = `https://docs.google.com/viewer?url=${encodedPdfUrl}&embedded=true`;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/90 backdrop-blur-sm flex flex-col justify-between overflow-hidden animate-fadeIn">
      {/* Top Header Bar */}
      <div className="bg-slate-900 border-b border-slate-800 text-white px-4 py-3 flex items-center justify-between shrink-0 shadow-lg">
        <div className="flex items-center gap-3 min-w-0 pr-2">
          <div className="w-9 h-9 rounded-lg bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div className="truncate">
            <h3 className="font-semibold text-sm truncate text-white">{pdf.title}</h3>
            <div className="flex items-center gap-2 text-[11px] text-slate-400 truncate">
              <span className="bg-slate-800 px-1.5 py-0.5 rounded text-indigo-300 border border-slate-700">
                {pdf.category || 'Study PDF'}
              </span>
              <span>•</span>
              <span>{formatSize(pdf.fileSize)}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => setZoomLevel((z) => Math.min(z + 25, 200))}
            title="Zoom In"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoomLevel((z) => Math.max(z - 25, 50))}
            title="Zoom Out"
            className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          
          <a
            href={pdf.storageUrl}
            target="_blank"
            rel="noopener noreferrer"
            download={pdf.fileName || `${pdf.title}.pdf`}
            title="Download PDF"
            className="p-1.5 text-indigo-400 hover:text-indigo-300 hover:bg-indigo-950/50 rounded-lg transition"
          >
            <Download className="w-4 h-4" />
          </a>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-red-500/20 hover:text-red-400 rounded-lg transition ml-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main PDF Content Canvas */}
      <div className="flex-1 bg-slate-950 overflow-auto p-2 flex flex-col items-center justify-center relative">
        <div 
          style={{ width: `${zoomLevel}%`, maxWidth: '100%', height: '100%' }} 
          className="transition-all duration-200 flex flex-col h-full w-full max-w-4xl bg-white rounded-lg shadow-2xl overflow-hidden border border-slate-800"
        >
          {useGoogleViewer ? (
            <iframe
              src={googleViewerUrl}
              className="w-full h-full border-0"
              title={pdf.title}
              onError={() => setUseGoogleViewer(false)}
            />
          ) : (
            <object
              data={pdf.storageUrl}
              type="application/pdf"
              className="w-full h-full border-0"
            >
              <div className="p-8 text-center text-slate-700 space-y-4 my-auto">
                <FileText className="w-16 h-16 mx-auto text-indigo-500 opacity-60" />
                <p className="font-medium text-sm">Unable to render PDF directly in frame.</p>
                <a
                  href={pdf.storageUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white font-medium text-xs rounded-lg hover:bg-indigo-700 shadow"
                >
                  <ExternalLink className="w-4 h-4" /> Open PDF in External Viewer
                </a>
              </div>
            </object>
          )}
        </div>
      </div>

      {/* Footer info bar */}
      <div className="bg-slate-900 border-t border-slate-800 text-slate-400 px-4 py-2 flex items-center justify-between text-xs shrink-0">
        <div className="flex items-center gap-2 truncate">
          <FolderOpen className="w-3.5 h-3.5 text-slate-500" />
          <span className="truncate">{pdf.description || 'No description provided.'}</span>
        </div>
        <div className="flex items-center gap-3 shrink-0 text-[11px]">
          <button 
            onClick={() => setUseGoogleViewer(!useGoogleViewer)}
            className="text-indigo-400 hover:underline"
          >
            {useGoogleViewer ? 'Direct Embed Mode' : 'Google Viewer Mode'}
          </button>
          <span>Zoom: {zoomLevel}%</span>
        </div>
      </div>
    </div>
  );
};
